class Persona:
    pass
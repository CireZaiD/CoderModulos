from setuptools import setup

setup(
    name='nombre',
    version='1',
    description='descript',
    author_email= 'to@soy.yo',

    packages=['Modulo']
)
from Modulo.persona import Persona
def llamado_persona():
    return Persona()